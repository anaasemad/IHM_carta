#pragma once
#ifndef MAINWINDOW_H
#define MAINWINDOW_H


#include <QGraphicsScene>
#include <QGraphicsView>
#include <QMainWindow>
#include <QGraphicsLineItem>
#include "tool.h"

#include <qlistwidget.h>
QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    bool eventFilter(QObject *obj, QEvent *event) override;

private slots:
    void on_Btransportador_clicked();
    void on_Bregla_clicked();
    void on_boton_lista_clicked();
    void setDrawLineMode(bool enabled);
 //   void on_listWidget_itemClicked(QListWidgetItem *item);

private:
    Ui::MainWindow *ui;
   // QGraphicsScene *sceneMenu;
    QGraphicsScene *sceneMapa;
  //  QGraphicsScene *sceneCompas;
    QGraphicsView *view;
    double scale=1.0;

    Tool* transportador;
    Tool* regla;

    void applyZoom(double factor);
    QAction *m_actDrawLine = nullptr;
    bool m_drawLineMode = false;
    QGraphicsLineItem *m_tempLine = nullptr;
    QGraphicsLineItem *m_currentLineItem = nullptr;
    QPointF m_lineStart;
};
#endif // MAINWINDOW_H
